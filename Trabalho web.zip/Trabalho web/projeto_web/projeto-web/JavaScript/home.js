const url = "https://go-wash-api.onrender.com/api/user"

async function cadastreEndereco(){
    window.location.href = "endereco.html"
    
}